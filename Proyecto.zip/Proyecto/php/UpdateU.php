<?php

include("Conexion.php");
$con=conectar();

$Nombre=$_POST['Nombre'];
$Apellidos=$_POST['Apellidos'];
$Identificacion=$_POST['Identificacion'];
$Telefono=$_POST['Telefono'];
$Telefono_Movil=$_POST['Telefono_Movil'];
$Correo=$_POST['Correo'];
$Contraseña=$_POST['Contraseña'];

$sql="UPDATE clientes SET  Nombre='$Nombre',Apellidos='$Apellidos',Identificacion='$Identificacion',Telefono='$Telefono',Telefono_Movil='$Telefono_Movil',Correo='$Correo',Contraseña='$Contraseña'WHERE Identificacion='$Identificacion'";

$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: Usuario.php");
    }
?>