<?php


include("Conexion.php");
$con=conectar();

$Id_Mascotas=$_POST['Id_Mascotas'];
$Nombre=$_POST['Nombre'];
$Genero=$_POST['Genero'];
$Id_Raza=$_POST['Id_Raza'];
$Edad=$_POST['Edad'];  
$Tamaño=$_POST['Tamaño'];
$Identificacion=$_POST['Identificacion'];



$sql="UPDATE Mascotas SET  Nombre='$Nombre',Genero='$Genero',Id_Raza='$Id_Raza',Edad='$Edad',Tamaño='$Tamaño',identificacion='$Identificacion' WHERE Identificacion='$Id'";

$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: Mascotas.php");
    }

?>
