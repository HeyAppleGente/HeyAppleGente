<?php 
include("Conexion.php");
$con=conectar();

$Id=$_GET['Identificacion'];



$sql="SELECT * FROM Mascotas WHERE Identificacion='$Id'";
$query=mysqli_query($con,$sql);

$row=mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Actualizar</title>
        
    </head>
    <body>
                <div class="container mt-5">
                    <form action="UpdateM.php" method="POST">
                    
                                <input type="hidden" name="Identificacion" value="<?php echo $row['Identificacion']  ?>">     
                                <input type="text" class="form-control mb-3" name="Nombre" placeholder="Nombre" value="<?php echo $row['Nombre']?>">
                                <input type="text" class="form-control mb-3" name="Genero" placeholder="Genero" value="<?php echo $row['Genero']?>">
                                <input type="text" class="form-control mb-3" name="Id_Raza" placeholder="Id_Raza" value="<?php echo $row['Id_Raza']?>">
                                <input type="text" class="form-control mb-3" name="Edad" placeholder="Edad" value="<?php echo $row['Edad']?>">
                                <input type="text" class="form-control mb-3" name="Tamaño" placeholder="Tamaño" value="<?php echo $row['Tamaño']?>">
                                
                                
                            <input type="submit" class="btn btn-primary btn-block" value="Enviar">
                    </form>
                    
                </div>
    </body>
</html>