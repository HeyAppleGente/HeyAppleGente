<?php
include("Conexion.php");
$con=conectar();

    $sql="SELECT *  FROM Mascotas";
    $query=mysqli_query($con,$sql);
    $row=mysqli_fetch_array($query);

   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse</title>
    <link rel="stylesheet" href="../css/Registro.css">
    <link rel="stylesheet" href="../css/Password.css">
    <link rel="shortcut icon" href="https://fontawesome.com/v4/icons/" type="image/x-icon">
    
</head>
<body>
<header>
        <pre class="titulo">                  </pre>
        <div class="header">
            <div class="nombre">
                <h1>AdogT-Aqui</h1>
            </div>
            <ul>
                <li><a href="../inicio.html">Inicio</a></li>
                <li><a href="mascotas.html">Mascotas</a></li>
                <li><a href="sobrenosotros.html">Sobre nosotros</a></li>
                <li><a href="Login.html">Loging</a></li>
            </ul>
        </div>
        </div>

    </header>
    <div class="container">
        <div class="screen">  
            <div class="screen_content">
                <form class="login"  action="InsertarM.php"  method="Post">
                    <div class="login_field">
                        <i class="login_icon fas fa-user"></i>
                        <input type="text" class="login_input" placeholder="Nombre" name="Nombre">
                    </div>
                    <div class="login_field">
                        <i class="login_icon fas fa-lock"></i>
                        <input type="text" class="login_input" placeholder="Genero" name="Genero">
                    </div>
                    <div class="login_field">
                        <i class="login_icon fas fa-lock"></i>
                        <input type="text" class="login_input" placeholder="Id_Raza" name="Id_Raza">
                    </div>
                    <div class="login_field">
                        <i class="login_icon fas fa-lock"></i>
                        <input type="text" class="login_input" placeholder="Edad" name="Edad">
                    </div>
                    <div class="login_field">
                        <i class="login_icon fas fa-lock"></i>
                        <input type="text" class="login_input" placeholder="Tamaño" name="Tamaño">
                    </div>
                    <div class="login_field">
                        <i class="login_icon fas fa-user"></i>
                        <input type="text" class="login_input" placeholder="Identificacion" name="Identificacion">
                    </div>
                    <button class="button login_submit">
                        <input type="Submit" value="Registrarse">
                        <i class="button_icon fas fa-chevron-right"></i>
                    </button>
                </form>
            </div>
            <div class="screen_background">
                <span class="screen_background_shape screen_background_shape4"></span>
                <span class="screen_background_shape screen_background_shape3"></span>
                <span class="screen_background_shape screen_background_shape2"></span>
                <span class="screen_background_shape screen_background_shape1"></span>
            </div>
        </div>
    </div>
    <h1>lista de Mascotas</h1>
    
    <table>
        <tr>
            <th>Nombre</th>
            <th>Genero</th>
            <th>Id_Raza</th>
            <th>Edad</th>
            <th>Tamaño</th>
            <th>Foto</th>
            <th>Identificacion</th>
        </tr>
        <?php
        while($row=mysqli_fetch_array($query)){
        ?>
        <tr>
            <td><?php echo $row["Nombre"]?></td>
            <td><?php echo $row["Genero"]?></td>
            <td><?php echo $row["Id_Raza"]?></td>
            <td><?php echo $row["Edad"]?></td>
            <td><?php echo $row["Tamaño"]?></td>
            <td><?php echo $row["Foto"]?></td>
            <td><?php echo $row["Identificacion"]?></td>
            <td><a href="ActualizarM.php?Identificacion=<?php echo $row['Identificacion']?>">Editar</a></td>
            <td><a href="EliminarM.php?Identificacion=<?php echo $row['Identificacion']?>">Eliminar</a></td>
        </tr>
        <?php
        }
        ?>
    </table>
</body>
</html>