<?php
include("Conexion.php");
$con=conectar();

    $sql="SELECT *  FROM clientes";
    $query=mysqli_query($con,$sql);
    $row=mysqli_fetch_array($query);

   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse</title>
    <link rel="stylesheet" href="../css/Registro.css">
    <link rel="stylesheet" href="css/Password.js">
    <link rel="shortcut icon" href="https://fontawesome.com/v4/icons/" type="image/x-icon">
    
</head>
<header>
        <pre class="titulo">                  </pre>
        <div class="header">
            <div class="nombre">
                <h1>AdogT-Aqui</h1>
            </div>
            <ul>
                <li><a href="inicio.html">Inicio</a></li>
                <li><a href="mascotas.html">Mascotas</a></li>
                <li><a href="sobrenosotros.html">Sobre nosotros</a></li>
            </ul>
        </div>
        </div>

    </header>
<body>
    <div class="container">
        <div class="screen">  
            <div class="screen_content">
                <form class="login"  action="InsertarU.php"  method="Post">
                    <div class="login_field">
                        <i class="login_icon fas fa-user"></i>
                        <input type="text" class="login_input" placeholder="Nombre" name="Nombre">
                    </div>
                    <div class="login_field">
                        <i class="login_icon fas fa-lock"></i>
                        <input type="text" class="login_input" placeholder="Apellidos" name="Apellidos">
                    </div>
                    <div class="login_field">
                        <i class="login_icon fas fa-lock"></i>
                        <input type="text" class="login_input" placeholder="Identificacion" name="Identificacion">
                    </div>
                    <div class="login_field">
                        <i class="login_icon fas fa-lock"></i>
                        <input type="text" class="login_input" placeholder="Telefono" name="Telefono">
                    </div>
                    <div class="login_field">
                        <i class="login_icon fas fa-lock"></i>
                        <input type="text" class="login_input" placeholder="Tele_Movil" name="Telefono_Movil">
                    </div>
                    <div class="login_field">
                        <i class="login_icon fas fa-lock"></i>
                        <input type="text" class="login_input" placeholder="Correo" name="Correo">
                    </div>
                    <div class="login_field">
                        <i class="login_icon fas fa-lock"></i>
                        <input type="password" class="login_input" placeholder="Contraseña" name="Contraseña">
                    </div>
                    <button class="button login_submit">
                        <input type="Submit" value="Registrarse">
                        <i class="button_icon fas fa-chevron-right"></i>
                    </button>
                </form>
            </div>
            <div class="screen_background">
                <span class="screen_background_shape screen_background_shape4"></span>
                <span class="screen_background_shape screen_background_shape3"></span>
                <span class="screen_background_shape screen_background_shape2"></span>
                <span class="screen_background_shape screen_background_shape1"></span>
            </div>
        </div>
    </div>
    <h1>lista de clientes</h1>
    
    <table>
        <tr>
            <th>Nombre</th>
            <th>Apellidos</th>
            <th>Identificacion</th>
            <th>Telefono</th>
            <th>Tele_Movil</th>
            <th>Correo</th>
        </tr>
        <?php
        while($row=mysqli_fetch_array($query)){
        ?>
        <tr>
            <td><?php echo $row["Nombre"]?></td>
            <td><?php echo $row["Apellidos"]?></td>
            <td><?php echo $row["Identificacion"]?></td>
            <td><?php echo $row["Telefono"]?></td>
            <td><?php echo $row["Telefono_Movil"]?></td>
            <td><?php echo $row["Correo"]?></td>
            <td><a href="ActualizarU.php?Identificacion=<?php echo $row['Identificacion']?>">Editar</a></td>
            <td><a href="EliminarU.php?Identificacion=<?php echo $row['Identificacion']?>">Eliminar</a></td>
        </tr>
        <?php
        }
        ?>
    </table>
</body>
</html>