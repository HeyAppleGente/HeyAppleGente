
            if (window.parent) {
                var _w = 0, _h = 0;
                var updateFormSize = function () {
                    var form = $('form.shaped-form-extended,form.shaped-form');
                    var w = form.outerWidth(true);
                    var h = form.outerHeight(true);
                    if (Math.abs(_w - w) > 5 || Math.abs(_h - h) > 5) {
                        _w = w;
                        _h = h;
                        var msg = { key: 'login-frame-size', width: w, height: h };
                        window.parent.postMessage(msg, "*");
                    }
                    setTimeout(updateFormSize, 300);
                }
                updateFormSize();
            }
        